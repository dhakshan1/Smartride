# SmartRide — Working Front-End Prototype

## Features
- Search sample bus routes by destination and departure period
- View demo seat availability and fares
- Reserve demo seats and update availability
- Rule-based transport chatbot
- Admin dashboard with booking summary
- Publish route status updates visible to students
- Responsive desktop/mobile layout

## Run
Open `index.html` in any modern browser. No installation is required.

## Push to GitHub
Create a repository named `SmartRide`, then open a terminal in this folder and run:

```bash
git init
git add .
git commit -m "Add SmartRide working prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/SmartRide.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If your repository already exists, use its URL.

## Limitations
This prototype uses in-memory sample data. Bookings and route updates reset when the page refreshes. There is no real login, backend database, live GPS, real payment system, or production AI integration. Clearly identify bus schedules, seat counts, fares and updates as demo data.
